package com.kilo.kilo.ui.registrarmantenimiento

import com.kilo.kilo.data.TipoPieza

data class RegistrarMantenimientoState(
    val tipos: List<String> = TipoPieza.values().map { it.nombre },
    val tipoSeleccionado: String = TipoPieza.ACEITE.nombre,
    val fecha: String = "13/09/2026",
    val kmDelCambio: String = "68450",
    val notas: String = "",
    val error: String? = null
)