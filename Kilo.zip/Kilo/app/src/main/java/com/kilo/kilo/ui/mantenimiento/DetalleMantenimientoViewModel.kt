package com.kilo.kilo.ui.mantenimiento

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kilo.kilo.data.CalculoMantenimiento
import com.kilo.kilo.data.DatosKilo
import com.kilo.kilo.data.KiloRepository
import com.kilo.kilo.data.RegistroMantenimiento
import com.kilo.kilo.data.TipoPieza
import com.kilo.kilo.data.conComas
import com.kilo.kilo.data.formatoCorto
import com.kilo.kilo.ui.piezasporcategorias.aEstadoPieza
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

@HiltViewModel
class DetalleMantenimientoViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    repositorio: KiloRepository
) : ViewModel() {

    /** La pieza llega como argumento de la ruta: detalle_mantenimiento/{tipo}. */
    private val tipo: TipoPieza =
        TipoPieza.desdeClave(savedStateHandle.get<String>("tipo")) ?: TipoPieza.ACEITE

    private val mostrarRegistro = MutableStateFlow(false)

    val state: StateFlow<DetalleMantenimientoState> = combine(
        repositorio.datos,
        mostrarRegistro
    ) { datos, mostrar -> construirEstado(tipo, datos, mostrar) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = construirEstado(tipo, repositorio.datos.value, false)
        )

    /** "Marcar como realizado" abre la hoja Registrar mantenimiento. */
    fun onMarcarRealizado() {
        mostrarRegistro.value = true
    }

    fun onCerrarRegistro() {
        mostrarRegistro.value = false
    }
}

private fun construirEstado(
    tipo: TipoPieza,
    datos: DatosKilo,
    mostrarRegistro: Boolean
): DetalleMantenimientoState {
    val e = CalculoMantenimiento.estadoDe(tipo, datos)
    val km = { valor: Int? -> valor?.let { "${it.conComas()} km" } ?: "—" }

    val historial = datos.registros
        .filter { it.tipo == tipo }
        .sortedWith(
            compareByDescending<RegistroMantenimiento> { it.km }.thenByDescending { it.fecha }
        )
        .map { r ->
            RegistroDetalle(
                km = km(r.km),
                detalle = listOfNotNull(
                    r.fecha.formatoCorto(),
                    r.nota.takeIf { it.isNotBlank() }
                ).joinToString(" · ")
            )
        }

    return DetalleMantenimientoState(
        titulo = tipo.nombre,
        intervalo = tipo.descripcionIntervalo,
        estado = e.situacion.aEstadoPieza(),
        etiquetaEstado = e.situacion.etiqueta,
        progreso = e.progreso.coerceIn(0f, 1f),
        ultimoKm = km(e.ultimo?.km),
        metaKm = km(e.kmMeta),
        proximoCambio = km(e.kmMeta),
        fechaLimite = e.fechaLimite?.formatoCorto() ?: "—",
        historial = historial,
        mostrarRegistro = mostrarRegistro,
        tipoClave = tipo.name
    )
}